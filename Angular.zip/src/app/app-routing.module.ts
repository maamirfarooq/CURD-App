import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';

export const routes: Routes = [    
  {    
    path: '',    
    redirectTo: 'employee',    
    pathMatch: 'full',    
  },    
     
  {    
    path: 'Dasboard',    
    component: EmployeeComponent,    
    data: {    
      title: 'Dashboard Page'    
    }    
  },      
];    
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
