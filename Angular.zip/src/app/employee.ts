export class Employee {
    EmployeeID :string;
     Name :string;
     Position :string;
     Office :string;
    Age :string
    Salary :string
    ng
    // EmpId: string;
    // EmpName: string;
    // DateOfBirth: Date;
    // EmailId: string;
    // Gender: string;
    // Address: string;
    // PinCode: string;
}
